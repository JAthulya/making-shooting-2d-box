﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double num1,num2,sum;
            num1 = double.Parse(txtnum1.Text);
            num2 = double.Parse(txtnum2.Text);

            sum = num1 + num2;

            lbl1.Text = num1.ToString();
            lbl2.Text = "+";
            lbl3.Text = num2.ToString();
            lbl4.Text = "=";
            lbl5.Text = sum.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            double num1, num2,dev ;
            num1 = double.Parse(txtnum1.Text);
            num2 = double.Parse(txtnum2.Text);

            dev = num1 - num2;

            lbl1.Text = num1.ToString();
            lbl2.Text = "-";
            lbl3.Text = num2.ToString();
            lbl4.Text = "=";
            lbl5.Text = dev.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            double num1, num2, mul;
            num1 = double.Parse(txtnum1.Text);
            num2 = double.Parse(txtnum2.Text);

            mul = num1 * num2;

            lbl1.Text = num1.ToString();
            lbl2.Text = "x";
            lbl3.Text = num2.ToString();
            lbl4.Text = "=";
            lbl5.Text = mul.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            double num1, num2, div;
            num1 = double.Parse(txtnum1.Text);
            num2 = double.Parse(txtnum2.Text);

            div = num1 / num2;
            div = Math.Round(div, 2);

            lbl1.Text = num1.ToString();
            lbl2.Text = "/";
            lbl3.Text = num2.ToString();
            lbl4.Text = "=";
            lbl5.Text = div.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {


            txtnum1.Text = "";
            txtnum2.Text = "";
            lbl1.Text = "";
            lbl2.Text = "";
            lbl3.Text = "";
            lbl4.Text = "";
            lbl5.Text = "";
        }
    }
}
